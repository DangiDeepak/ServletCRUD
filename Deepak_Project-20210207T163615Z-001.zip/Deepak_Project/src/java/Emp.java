public class Emp {  
private int id;  
private String uname,password,fname;  
public int getId() {  
    return id;  
}  
public void setId(int id) {  
    this.id = id;  
}  
public String getuName() {  
    return uname;  
}  
public void setuName(String name) {  
    this.uname = name;  
} 

public String getfName() {  
    return fname;  
}  
public void setfName(String name) {  
    this.fname = name;  
} 
public String getPassword() {  
    return password;  
}  
public void setPassword(String password) {  
    this.password = password;  
}  
}  
